// functions/myNewFunction/index.mjs
export const handler = async (event, context) => {
  // Your function logic here
  return {
    statusCode: 200,
    body: {
      message:
        "Hello from myNewFunction! will test dev again watch please ya rab ya rab asra3 please",
    },
  };
};
